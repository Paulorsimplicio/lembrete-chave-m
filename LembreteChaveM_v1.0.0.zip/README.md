# 🔐 Lembrete Chave M (Foursys • Bradesco)

Um gadget desktop moderno, leve e 100% offline desenvolvido para lembrar os colaboradores da **Foursys** alocados no cliente **Bradesco** sobre o prazo de renovação da senha da **Chave M** antes que ela expire.

---

## 🚀 Características Principais

- **🔒 100% Offline e Privado:** Não necessita de conexão com a internet, banco de dados externo ou APIs. Todos os dados são salvos localmente no perfil do usuário (`~/.foursys_chave_m/config.json`).
- **💻 Multiplataforma:** Compatível com **Windows**, **macOS** e **Linux**.
- **🔔 Notificações Nativas do Sistema:** Emite alertas diretamente na central de notificações do sistema operacional:
  - ⚠️ **7 dias antes:** Aviso preventivo para planejamento da troca.
  - ⚠️ **3 dias antes:** Alerta de atenção com prazo curto.
  - 🚨 **1 dia antes (Amanhã):** Alerta urgente para troca imediata.
  - 🚨 **No dia da expiração:** Alerta máximo para evitar bloqueio de acessos.
- **🕒 Bandeja do Sistema (System Tray):** Fica minimizado perto do relógio do sistema, consumindo praticamente zero memória/processamento.
- **⚡ Registro Rápido:** Botão *"Troquei Minha Senha Hoje"* para atualizar o ciclo com apenas 1 clique, ou seletor para datas retroativas.
- **🔄 Inicialização Automática:** Opção para iniciar junto com o computador (Windows Run, Linux autostart, macOS LaunchAgents).
- **📦 Executável Portátil:** Não exige que o usuário final tenha Python instalado — pode ser distribuído como um único arquivo `.exe`.

---

## 📁 Estrutura do Projeto

```
automacao-foursys/
├── assets/
│   ├── icon.png            # Ícone oficial em alta resolução
│   └── icon.ico            # Ícone formatado para Windows
├── src/
│   ├── config.py           # Regras de negócio, prazos e cores visuais
│   ├── storage.py          # Gerenciamento de persistência local (JSON)
│   ├── reminder_engine.py  # Cálculo de dias restantes, status e limiares
│   ├── notifier.py         # Disparador de notificações nativas do SO
│   ├── autostart.py        # Gerenciador de inicialização no boot
│   ├── tray.py             # Integração com a bandeja do sistema (System Tray)
│   └── gui.py              # Interface gráfica moderna (CustomTkinter)
├── tests/
│   ├── test_storage.py     # Testes unitários do armazenamento
│   └── test_reminder_engine.py # Testes dos cálculos de expiração e alertas
├── dist/
│   └── LembreteChaveM.exe  # Executável portátil para Windows (sem dependências)
├── build_exe.py            # Script PyInstaller para compilação multiplataforma
├── build_exe.bat           # Gerador automático do .exe em 1 clique (Windows)
├── run.bat                 # Atalho para executar via Python em segundo plano
├── main.py                 # Ponto de entrada da aplicação
└── requirements.txt        # Dependências do projeto
```

---

## 🛠️ Como Utilizar

### Opção 1: Executar o `.exe` Portátil (Para usuários finais)
1. Vá até a pasta `dist/` e execute o arquivo `LembreteChaveM.exe`.
2. O aplicativo abrirá imediatamente.
3. Clique em **"Troquei Minha Senha Hoje"** (ou digite a data em que você realizou a última troca).
4. Pronto! O gadget calculará os 30 dias de validade e cuidará dos lembretes.

---

### Opção 2: Executar via Código Python (Desenvolvimento)

1. **Criar e ativar o ambiente virtual:**
   ```bash
   python -m venv .venv
   .\.venv\Scripts\activate       # No Windows
   # source .venv/bin/activate    # No Linux/Mac
   ```

2. **Instalar as dependências:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Executar a aplicação:**
   ```bash
   python main.py
   ```

4. **Executar os testes unitários:**
   ```bash
   python -m unittest discover tests
   ```

---

## 📦 Como Gerar um Novo Executável (.exe ou binário)

Para compilar novamente o executável caso faça alterações no código:

- **No Windows:** Dê duplo clique no script [build_exe.bat](file:///c:/Projetos/automacao-foursys/build_exe.bat) ou execute:
  ```bash
  python build_exe.py
  ```
- **No Linux/Mac:**
  ```bash
  python3 build_exe.py
  ```
O arquivo final será gerado automaticamente na pasta `dist/`.

---

## 🔒 Privacidade e Segurança
Este aplicativo **não** armazena sua senha nem solicita credenciais de login. Ele apenas guarda a **data da troca** para efetuar a contagem regressiva dos 30 dias.
